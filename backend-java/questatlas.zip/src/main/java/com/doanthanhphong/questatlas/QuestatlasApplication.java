package com.doanthanhphong.questatlas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuestatlasApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuestatlasApplication.class, args);
	}

}
